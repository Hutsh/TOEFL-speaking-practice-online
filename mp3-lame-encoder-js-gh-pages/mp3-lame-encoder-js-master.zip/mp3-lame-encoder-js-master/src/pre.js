(function(self) {
  var Module = self.Mp3LameEncoderConfig;
